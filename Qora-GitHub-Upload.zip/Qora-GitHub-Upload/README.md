# Qora website upload folder

This folder contains the Qora single-page website.

## Publish on GitHub Pages
1. Open your GitHub repository.
2. Upload `index.html` to the repository root (not inside another nested folder).
3. Commit the file to the branch selected in Settings → Pages (usually `main`).
4. In Settings → Pages, select “Deploy from a branch”, branch `main`, folder `/(root)`, then Save.
5. Wait for the deployment to finish and open the URL shown in Settings → Pages.

Note: This is a static frontend. Any connected APIs or backend services must be configured separately.
